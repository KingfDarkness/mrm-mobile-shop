// Basic interactions can go here
console.log('MRM Mobile Shop Loaded');
